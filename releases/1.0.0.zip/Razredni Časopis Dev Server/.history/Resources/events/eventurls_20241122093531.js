export const eventUrls = {
  "Hitro Tipkanje": [
      "https://razrednicasopis.github.io/Resources/events/hitrotipkanje/domov.html", // Live URL
      "http://127.0.0.1:5500/Resources/events/hitrotipkanje/domov.html" // Localhost URL
  ],
  "Festival Iger": [
    "https://razrednicasopis.github.io/Resources/events//domov.html"
    "http://127.0.0.1:5500/Resources/events/festival_iger/domov.html", 
    "http://127.0.0.1:5500/Resources/events/festival_iger/igre/slytherio.html"
  ], // Add your specific URLs for guessingGame event
  // Add other events and their corresponding URLs here
};
